#!/usr/bin/python3

def main():
    print('Welcome to the Brain Games!')
    return

if __name__ == "__main__":
    main()


